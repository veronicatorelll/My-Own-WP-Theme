<!------ För enskilda nyheter ------->

<?php 
get_header();
?>

<div class="single-news">
   <h3 class="single-news-title"> <?php the_title(); ?> </h3>
   <div class="single-thumbnail">
    <?php the_post_thumbnail('thumbnail'); ?> </div>
    <span class="date"> <?php the_time(get_option('date_format')); ?> </span>
   <div class="single-news-content"> <?php the_content(); ?> </div>
</div>

<a class="back" href="./page-news.php"> < Tillbaka till nyheter</a>


<div class="copyright">
<?php 
get_footer();
?>
</div>
