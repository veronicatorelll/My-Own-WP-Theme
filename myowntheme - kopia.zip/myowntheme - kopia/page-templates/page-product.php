 <!-- Template som används för sidan "Om produkten" -->

<?php /* Template Name: Product Page */ ?>

<?php 
get_header();
$site_title = get_bloginfo('name');
$site_url = network_site_url('/');
?>

<h1 class="header-logo">
<?php echo $site_title; ?>
</h1>

<h3 class="product-title"> <?php the_title(); ?> </h3>  
      <div class="product-img">
      <?php the_post_thumbnail ('large'); ?>
      </div>
         
      <div class="product-content">
        <?php the_content(); ?>
        </div>


    <?php wp_reset_postdata(); ?>

    <div class="copyright">
<?php 
get_footer();
?>
</div>
