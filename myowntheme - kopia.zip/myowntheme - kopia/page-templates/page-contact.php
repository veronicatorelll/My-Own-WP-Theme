 <!-- Template som används för sidan "Kontakta oss" -->

<?php /* Template Name: Contact Page */ ?>

<?php 
get_header();
$site_title = get_bloginfo('name');
$site_url = network_site_url('/');
?>

<h1 class="header-logo">
<?php echo $site_title; ?>
</h1>

<h3 class="contact-title"><?php the_title(); ?> </h3>  
      <div class="contact-wrap">
        <?php the_content(); ?>
      </div>


    <?php wp_reset_postdata(); ?>

<div class="copyright">
<?php 
get_footer();
?>
</div>

