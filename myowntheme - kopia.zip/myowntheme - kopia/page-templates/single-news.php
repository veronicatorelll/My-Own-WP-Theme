 <!-- Template som används för undersidan för enskild nyhet -->

<?php /* Template Name: Single News */ ?>

<?php 
get_header();
$site_title = get_bloginfo('name');
$site_url = network_site_url('/');
?>

<h1 class="header-logo">
<?php echo $site_title; ?>
</h1>


<?php
$the_query = new WP_Query(array(
    'posts_per_page' => 100,
));
?>

<?php if ($the_query->have_posts()) : ?>
    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
     

      <h3 class="single-news-title"><?php the_title(); ?> </h3>  
      <span class="date"> <?php the_time(get_option('date_format')); ?> </span>
      <div class="single-news-content">
        <?php the_content(); ?>
      </div>


    <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>
    <?php endif; ?>

<a href="./page-news.php">Tillbaka till nyheter</a>

<div class="copyright">
<?php 
get_footer();
?>
</div>

