 <!-- Template som används för sidan "Om oss" -->
 
 <?php /* Template Name: About Template */ ?> 

<?php 
get_header();
$site_title = get_bloginfo('name');
$site_url = network_site_url('/');
?>

<h1 class="header-logo">
<?php echo $site_title; ?>
</h1>

      <div>
        <?php the_content(); ?>
      </div>

      

      <div class="about-news-wrapper">
      <h1 class="about-news-title">Nyheter</h1>
        
        <div class="news-template-about">
      <?php get_template_part('template-parts/template-news'); ?>
      </div>
      </div>

    <?php wp_reset_postdata(); ?>


<div class="copyright">
<?php 
get_footer();
?>
</div> 


