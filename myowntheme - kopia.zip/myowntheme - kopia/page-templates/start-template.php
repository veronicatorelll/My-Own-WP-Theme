 <!-- Template som används för sidan "Start" -->

<?php /* Template Name: Start Template */ ?>

<?php 
get_header();
$site_title = get_bloginfo('name');
$site_url = network_site_url('/');
?>

<h1 class="header-logo">
<?php echo $site_title; ?>
</h1>
      <div>
        <?php the_content(); ?>
      </div>

      <?php get_template_part('template-parts/template-news'); ?>

    <?php wp_reset_postdata(); ?>


<div class="copyright">
<?php 
get_footer();
?>
</div>