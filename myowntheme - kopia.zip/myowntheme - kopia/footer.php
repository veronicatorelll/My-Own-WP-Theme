<span class="copyright"> &copy; DEVSNEAKERS <?php echo date("Y");?>. All rights reserved.</span>
