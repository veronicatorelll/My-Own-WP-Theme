<!-- Används som tmeplate på start och om oss -->
<?php 
get_header();
?>

<h1 class="header-logo">
<?php echo $site_title; ?>
</h1>


<div class="-template-news-wrap">
<?php
$the_query = new WP_Query(array(
    'posts_per_page' => 4,
));
?>
<?php if ($the_query->have_posts()) : ?>
    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>



        <div class="news-wrapper">

        <a class="permalink" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">


        <div class="thumbnail"> <?php the_post_thumbnail('thumbnail'); ?> </div> </a>

      <h3 class="newspage-title"><?php the_title(); ?> </h3>   
      <span class="date"> <?php the_time(get_option('date_format')); ?> </span>
      <span class="news-content">
        <?php the_content(); ?>
        </div>
        </span>






    <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>

    <?php endif; ?>
    </div>


<div class="copyright">
<?php 
get_footer();
?>
</div>

