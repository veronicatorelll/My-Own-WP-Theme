<?php
add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles', 11);

function my_theme_enqueue_styles()
{
  wp_enqueue_style('style', get_stylesheet_uri());
}

add_theme_support('post-thumbnails');


function new_excerpt_more($more)
{
    return '...';
}
add_filter('excerpt_more', 'new_excerpt_more');

register_nav_menus(array('main-menu' => esc_html__('Main Menu', 'myowntheme')));


// ----------- För ACF ------------
add_action('acf/init', 'my_acf_init_block_type');
function my_acf_init_block_type() {

    if( function_exists('acf_register_block_type') ) {

        acf_register_block_type(array(
            'name'              => 'hero',
            'title'             => __('Hero'),
            'description'       => __('A custom hero block.'),
            'render_template'   => 'template-parts/blocks/hero.php',
            'category'          => 'formatting',
            'keywords'          => array('hero'),
        ));
    }
}

